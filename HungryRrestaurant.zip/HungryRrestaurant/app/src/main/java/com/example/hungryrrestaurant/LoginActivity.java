package com.example.hungryrrestaurant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {
    private EditText login_phone,login_password;
    private Button userlogin;
    private ProgressDialog loadingbar;

    private String parentDbName = "Users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        userlogin = (Button) findViewById(R.id.userlogin);
        login_phone = (EditText) findViewById(R.id.login_phone);
        login_password = (EditText) findViewById(R.id.login_password);
        loadingbar = new ProgressDialog(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        String phone = login_phone.getText().toString();
        String password = login_password.getText().toString();
        if (TextUtils.isEmpty(phone))
        {
            Toast.makeText(this, "Please Write your Phone Number", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please Write your Password", Toast.LENGTH_SHORT).show();
        }
        else
            {
                loadingbar.setTitle("Login Account");
                loadingbar.setMessage("Please Wait for sometime");
                loadingbar.setCanceledOnTouchOutside(false);
                loadingbar.show();

                AllowAccessToAccount(phone,password);

            }
    }

    private void AllowAccessToAccount(String phone, String password)
    {
        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();
        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(parentDbName).child(phone).exists())
                {


                }
                else
                    {
                        Toast.makeText(LoginActivity.this, "Account with this" + phone + "number is not exist. ", Toast.LENGTH_SHORT).show();
                        loadingbar.dismiss();

                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}