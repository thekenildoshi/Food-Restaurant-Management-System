package com.example.recyclertuts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

import com.example.recyclertuts.Adapters.RecipeAdapter;
import com.example.recyclertuts.Models.RecipeModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerview);

        ArrayList <RecipeModel> list = new ArrayList<>();
        list.add(new RecipeModel(R.drawable.food1,"Burger"));
        list.add(new RecipeModel(R.drawable.food2,"Pizza"));
        list.add(new RecipeModel(R.drawable.food3,"Cheese Burger"));
        list.add(new RecipeModel(R.drawable.food4,"Manchurian"));
        list.add(new RecipeModel(R.drawable.food5,"Egg-Burger"));
        list.add(new RecipeModel(R.drawable.food6,"French Fries"));
        list.add(new RecipeModel(R.drawable.food7,"Veg Noodles"));
        list.add(new RecipeModel(R.drawable.food8,"Cheese Pizza"));
        list.add(new RecipeModel(R.drawable.food9,"Panner"));
        list.add(new RecipeModel(R.drawable.food10,"Shushi"));
        list.add(new RecipeModel(R.drawable.food11,"Fry Manchurian"));
        list.add(new RecipeModel(R.drawable.food12,"Veg Rolls"));
        list.add(new RecipeModel(R.drawable.food13,"White Pasta"));

        RecipeAdapter adapter = new RecipeAdapter(list,this);
        recyclerView.setAdapter(adapter);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(gridLayoutManager);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
//        recyclerView.setLayoutManager(layoutManager);


    }
}